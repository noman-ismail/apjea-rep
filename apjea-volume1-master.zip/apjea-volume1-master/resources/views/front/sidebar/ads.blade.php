<div class="ad-box">
	<img src="compress/ad-image.jpg" class="img-fluid" alt="ads-image">
</div>