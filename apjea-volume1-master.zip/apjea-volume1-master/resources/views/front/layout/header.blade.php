<!DOCTYPE html>
<html lang="en">
<head>
	@include('front.layout.meta')
	<script src="{{ asset('assets/js/jquery.js') }}" id="jquery"></script>
    <style>
    	.my-50{
			margin: 50px 0;
		}
    </style>

