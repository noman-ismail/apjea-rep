<fieldset class="tb-content">

  <legend><h4>Table of Contents</h4></legend>

{!! $ct !!}

</fieldset>