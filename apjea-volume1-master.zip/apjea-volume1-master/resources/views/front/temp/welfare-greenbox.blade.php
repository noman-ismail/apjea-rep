<div class="col-lg-12 col-xl-6 second-column pl-0 pr-15">
  <div class="intro-box-two bg-green">
    <div class="small-box">
      <div class="row">
        <div class="col-3 col-sm-2 icon">
          <i class="fa fa-money"></i>
        </div>
        <h4 class="col-9 col-sm-10 small-head">Death Grant</h4>
      </div>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda ab facere beatae expedita a laborum rerum doloribus</p>
    </div>
    <div class="small-box">
      <div class="row">
        <div class="col-3 col-sm-2 icon">
          <i class="fa fa-fax"></i>
        </div>
        <h4 class="col-9 col-sm-10 small-head">Umrah Grant</h4>
      </div>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda ab facere beatae expedita a laborum rerum doloribus</p>
    </div>
  </div>
</div>
</div>