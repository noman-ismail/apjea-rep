<html lang="en">
	<head>
	    <meta charset="UTF-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	</head>
	<body style=" background:#ddd;padding:2%;font-family: Verdana, Geneva, Tahoma, sans-serif;">
	        <div style="max-width:600px;background:#fff;border-radius:20px;margin:0 auto;text-align:center;overflow:hidden;">
{{-- 	            <header>
	            <div style="text-align: center;padding: 5%;">
	                <img src="https://dgaps.com/images/DgAps-Logo.png" alt="banner image" >
	            </div>		
	            </header> --}}