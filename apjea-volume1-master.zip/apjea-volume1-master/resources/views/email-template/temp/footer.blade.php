<hr/>
 <footer style="margin:0 auto">
		<div style="display:flex;">
			<div style="width: 50%; float: right">
				<h4><span style="font-size:16px;font-weight:normal;color:black">Powered By:</span>
			 <a href="{{ route('base_url') }}" target="_blank" style="color:#d6352d;">APJEA Pakistan</a></h4>
			</div>
			<div style="width: 50%; float: left">
				<h4><span style="font-size:16px;font-weight:normal;color:black">Developed By:</span>
			 <a href="https://dgaps.com" target="_blank" style="color:#d6352d;">Digital Applications</a></h4>
			</div>
		</div>
	</footer>
</div>
</body>
</html>