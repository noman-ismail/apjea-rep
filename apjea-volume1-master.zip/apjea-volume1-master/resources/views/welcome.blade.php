Welocme to laravel 8
<br>
<a href="{{ route('login') }}" target="_blank">Login</a>
<br>
<a href="{{ route('admin') }}" target="_blank">Admin</a>