<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Homedata extends Model
{
    protected $table = "homedata";
    //
}
